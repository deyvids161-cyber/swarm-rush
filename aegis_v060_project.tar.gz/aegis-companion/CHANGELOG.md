# Changelog

## 0.6.0 — Command Center
- Painel gráfico com abas de comandos, trabalho, combate e status.
- Atalho P, comando `/aegis panel` e abertura pelo Núcleo do Aegis.
- Patrulha entre pontos A e B.
- Posturas passiva, defensiva, equilibrada e agressiva.
- Filtros de coleta: tudo, valiosos, equipamentos e recursos.
- Depósito automático em contêiner vinculado.
- Reabastecimento do dono com comida, flechas e tochas.
- Autoequipamento seguro com comparação de atributos.
- Retirada de emergência em vida baixa.
- Transferência de inventário, teleporte seguro e status ampliado.
- Compatibilidade genérica com itens, equipamentos e contêineres de mods.
