package br.com.aegiscompanion;

import br.com.aegiscompanion.config.AegisConfig;
import br.com.aegiscompanion.entity.AegisEntity;
import br.com.aegiscompanion.item.AegisCoreItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public final class AegisRegistry {
    private AegisRegistry() {}

    public static final EntityType<AegisEntity> AEGIS = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            AegisCompanionMod.id("aegis"),
            EntityType.Builder.<AegisEntity>of(AegisEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .updateInterval(3)
                    .build("aegis_companion:aegis")
    );

    public static final Item AEGIS_CORE = Registry.register(
            BuiltInRegistries.ITEM,
            AegisCompanionMod.id("aegis_core"),
            new AegisCoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))
    );

    public static void register() {
        AegisConfig cfg = AegisConfig.get();
        FabricDefaultAttributeRegistry.register(AEGIS, AegisEntity.createAttributes(cfg));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(AEGIS_CORE));
    }
}
