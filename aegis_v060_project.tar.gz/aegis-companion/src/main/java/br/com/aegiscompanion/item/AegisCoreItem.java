package br.com.aegiscompanion.item;

import br.com.aegiscompanion.AegisRegistry;
import br.com.aegiscompanion.entity.AegisEntity;
import br.com.aegiscompanion.network.AegisServerNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class AegisCoreItem extends Item {
    public AegisCoreItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        ServerLevel serverLevel = (ServerLevel) level;
        AegisEntity existing = findOwned(serverLevel, player);
        if (existing != null) {
            if (player.isShiftKeyDown() && player instanceof ServerPlayer serverPlayer) {
                AegisServerNetworking.openPanel(serverPlayer, existing);
            } else {
                existing.safeTeleportNear(player);
                player.sendSystemMessage(Component.translatable("aegis.message.recalled").withStyle(ChatFormatting.AQUA));
            }
            return InteractionResultHolder.consume(stack);
        }

        AegisEntity aegis = AegisRegistry.AEGIS.create(serverLevel);
        if (aegis == null) return InteractionResultHolder.fail(stack);
        aegis.moveTo(player.getX() + 1.0D, player.getY(), player.getZ() + 1.0D, player.getYRot(), 0.0F);
        aegis.bindTo(player);
        serverLevel.addFreshEntity(aegis);
        player.sendSystemMessage(Component.translatable("aegis.message.spawned").withStyle(ChatFormatting.AQUA));
        if (player.isShiftKeyDown() && player instanceof ServerPlayer serverPlayer) {
            AegisServerNetworking.openPanel(serverPlayer, aegis);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Nullable
    private static AegisEntity findOwned(ServerLevel level, Player player) {
        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof AegisEntity aegis && aegis.isAlive() && aegis.isOwnedBy(player)) return aegis;
        }
        return null;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Clique direito: invocar ou chamar o seu Aegis").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Shift + clique direito: abrir painel de controle").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("Tecla P: abrir painel em qualquer lugar da dimensão").withStyle(ChatFormatting.DARK_GRAY));
    }
}
